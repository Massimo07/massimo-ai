
import os
from bot import bot

if __name__ == "__main__":
    print("Massimo AI è in esecuzione...")
    bot.infinity_polling()
