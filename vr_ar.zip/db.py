# db.py
"""
Gestione database SQLite: prodotti, categorie, backup, import/export
"""
def backup_db():
    # TODO: copia il file DB corrente con timestamp
    print("Backup DB effettuato!")
    # ...codice backup

def import_products_from_csv(file_path):
    # TODO: importa prodotti da CSV
    pass

def export_products_to_csv(file_path):
    # TODO: esporta prodotti su CSV
    pass
